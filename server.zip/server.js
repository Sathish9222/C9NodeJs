var express = require('express');
var bodyParser = require('body-parser');
var request = require('request');
//Mail Code start
var api_key = 'key-d62649230090d467d58429e7bb5a6fe2';
var domain = 'sandboxa7e020269af84b46bc4ab2369299d172.mailgun.org';
var mailgun = require('mailgun-js')({ apiKey: api_key, domain: domain });
var path = require("path");

var filepath = path.join(__dirname, 'out.pdf');
var data = {
    from: 'sathishmit1159@gmail.com',
    to: 'sathishmit1159@gmail.com',
    subject: 'Statement for Last Month From Nuc Chat',
    text: 'Hey,Here is the statement for last month',
    attachment: filepath
};



// Mail Code End

var app = express();

const EventEmitter = require('events');

class Emitter extends EventEmitter { }

//Error handling code start
const emitter = new Emitter();
const logger = console;

/**
 * Add Error listener
 */
emitter.on('error', (err) => {
    logger.error('Unexpected error on emitter', err);
});
//Error handling Code End
// test the emitter
//emitter.emit('error', new Error('Whoops!'));
// Unexpected error on emitter Error: Whoops!


const SendOtp = require('sendotp');

var port = process.env.PORT || 3000;
var ip = process.env.IP || "127.0.0.1";

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.post('/', function (req, res, next) {
    try {
        console.log(req.body)
        var mobile;
        if (req.body.result.action == "statement") {
            mailgun.messages().send(data, function (error, body) {
                if (error) {
                    emitter.emit('error', new Error('Web Service Not Working!'));
                    res.json({
                        "speech": "There was a problem Sending mail",
                        "displayText": "There was a problem Sending mail"
                    })
                }
                else {
                    console.log(body);

                    res.json({
                        "speech": "Statement of last one month has been sent to registered mail id",
                        "displayText": "Statement of last one month been sent to registered mail id"
                    })
                }
            });
        }

        else if (req.body.result.action == "Status") {
            var postData = JSON.stringify({ "dateOfBirth": null, "loanAccountNumber": null, "primaryCustomerOnly": false, "requestChannel": "MSERV", "identificationTypeId": null, "requestHeader": { "userDetail": { "branchId": 5, "userCode": "SYSTEM" }, "tenantId": 505 }, "mobileNumber": "7171717171", "identificationNumber": null, "loanId": 5000291 });
            request.post({ headers: { 'content-type': 'application/json' }, url: 'http://10.1.60.83:9696/finnone-LMS/lms/customerService/getLoans', body: postData },
                function (error, response, body) {

                    if (response == undefined) {
                        emitter.emit('error', new Error('Web Service Not Working!'));

                    }
                    else if (response.statusCode == 200) {
                        var val = JSON.parse(body);
                        var loanAcNo = val.success[0].loanDetails[0].loanStatus;

                        if (loanAcNo == "A") {
                            loanAcNo = "Active";
                        }
                        else {
                            loanAcNo = "In Progress";
                        }
                        var Overdue = val.success[0].loanDetails[0].amountOverdue;
                        var loanAcNo1 ="The Current Status of your loan is "+ loanAcNo
                        res.json({
                            "speech": loanAcNo1,
                            "displayText": loanAcNo1
                        })
                    }
                });
        }

        else if (req.body.result.action == "overdue") {

            var postData = JSON.stringify({ "dateOfBirth": null, "loanAccountNumber": null, "primaryCustomerOnly": false, "requestChannel": "MSERV", "identificationTypeId": null, "requestHeader": { "userDetail": { "branchId": 5, "userCode": "SYSTEM" }, "tenantId": 505 }, "mobileNumber": "7171717171", "identificationNumber": null, "loanId": 5000291 });
            request.post({ headers: { 'content-type': 'application/json' }, url: 'http://10.1.60.83:9696/finnone-LMS/lms/customerService/getLoans', body: postData },
                function (error, response, body) {
                    if (response == undefined) {
                        emitter.emit('error', new Error('Web Service Not Working!'));
                    }
                    else if (response.statusCode == 200) {


                        var val = JSON.parse(body);
                        var loanAcNo = val.success[0].customerNumber;

                        var Overdue = val.success[0].loanDetails[0].amountOverdue;
                        var Overdue1="The Overdue amount as on today is" + Overdue;


                        res.json({
                            "speech": Overdue1,
                            "displayText": Overdue1
                        })
                    }
                });

        }
        else if (req.body.result.action == "name") {

            var postData = JSON.stringify({ "dateOfBirth": null, "loanAccountNumber": null, "primaryCustomerOnly": false, "requestChannel": "MSERV", "identificationTypeId": null, "requestHeader": { "userDetail": { "branchId": 5, "userCode": "SYSTEM" }, "tenantId": 505 }, "mobileNumber": "7171717171", "identificationNumber": null, "loanId": 5000291 });
            request.post({ headers: { 'content-type': 'application/json' }, url: 'http://10.1.60.83:9696/finnone-LMS/lms/customerService/getLoans', body: postData },
                function (error, response, body) {
                    if (response.statusCode == 200) {


                        var val = JSON.parse(body);
                        var loanAcNo = val.success[0].customerNumber;

                        var Name = val.success[0].customerName;
                        var Name1 ="Your good Name is" +Name;


                        res.json({
                            "speech": Name1,
                            "displayText": Name1
                        })
                    }
                });

        }

    }
    catch (Error) {
        console.log("Web Api Is not working");
    }
}); app.listen(port, ip);